import { I, c } from "./mermaid-parser.core.DxAe5yJl.js";
export {
  I as InfoModule,
  c as createInfoServices
};
