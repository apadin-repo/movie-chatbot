import { A, e } from "./mermaid-parser.core.DxAe5yJl.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
