import { G, f } from "./mermaid-parser.core.DxAe5yJl.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
