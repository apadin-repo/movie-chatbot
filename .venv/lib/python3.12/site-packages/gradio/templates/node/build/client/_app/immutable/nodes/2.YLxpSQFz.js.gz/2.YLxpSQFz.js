import { W, _ } from "../chunks/2.BFpN1SKc.js";
export {
  W as component,
  _ as universal
};
